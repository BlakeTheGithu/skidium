/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef NOSKIDIUM_PRIVATE_H
#define NOSKIDIUM_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"2.0.2.5"
#define VER_MAJOR	2
#define VER_MINOR	0
#define VER_RELEASE	2
#define VER_BUILD	5
#define COMPANY_NAME	"MazeIcon"
#define FILE_VERSION	"2.0.2.5"
#define FILE_DESCRIPTION	"No Skid"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	""
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	""
#define PRODUCT_VERSION	"2.0.2.5"

#endif /*NOSKIDIUM_PRIVATE_H*/
